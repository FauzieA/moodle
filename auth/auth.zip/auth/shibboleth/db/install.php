<?php

function xmldb_auth_shibboleth_install() {
    global $CFG, $DB;

}
