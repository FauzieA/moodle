# core_auth (subsystem / plugintype) Upgrade notes

## 5.0

### Removed

- Cas authentication is removed from core and added to the following git repository: https://github.com/moodlehq/moodle-auth_cas

  For more information see [MDL-78778](https://tracker.moodle.org/browse/MDL-78778)
- Removed auth_mnet plugin from core

  For more information see [MDL-84307](https://tracker.moodle.org/browse/MDL-84307)
