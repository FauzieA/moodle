CFPropertyList library
---------------

Downloaded latest release (2.0.5) from: https://github.com/moodlehq/CFPropertyList/tags

Import procedure:

- Copy all the files from the CFPropertyList-XXX/src/CFPropertyList folder into lib/plist/classes/CFPropertyList.
- Copy all the .md files from CFPropertyList-XXX to lib/plist/.

Removed:
 * .gitignore
 * composer.json
 * build.sh
 * examples
 * tests

Added:
 * readme_moodle.txt

