GeoPattern-PHP
-------

Downloaded from: https://github.com/RedeyeGroup/geopattern-php

Import procedure:

- Copy all the files from the folder 'src' this directory.
- Copy the license file from the project root.
- Remove the geopattern_loader.php file from the src directory, it is not needed.

Licensed under MIT, Copyright (c) 2015 Leaf Corcoran.
