# tool_lp Upgrade notes

## 5.0

### Deprecated

- behat_tool_lp_data_generators::the_following_lp_exist is deprecated. Use the following "core_competency > [competency|framework|plan...]" exist:

  For more information see [MDL-82866](https://tracker.moodle.org/browse/MDL-82866)
