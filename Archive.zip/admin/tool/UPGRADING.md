# tool (plugin type) Upgrade notes

## 4.5

### Removed

- The Convert to InnoDB plugin (`tool_innodb`) has been completely removed.

  For more information see [MDL-78776](https://tracker.moodle.org/browse/MDL-78776)
