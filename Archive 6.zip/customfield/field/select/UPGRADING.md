# customfield_select Upgrade notes

## 4.5

### Changed

- The field controller `get_options` method now returns each option pre-formatted.

  For more information see [MDL-82481](https://tracker.moodle.org/browse/MDL-82481)
