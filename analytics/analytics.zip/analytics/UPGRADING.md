# core_analytics (subsystem) Upgrade notes

## 5.0

### Removed

- Remove chat and survey from core_analytics.

  For more information see [MDL-82457](https://tracker.moodle.org/browse/MDL-82457)
