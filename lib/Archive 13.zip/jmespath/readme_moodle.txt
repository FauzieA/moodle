Instructions to import/update jmespath library into Moodle:

Update jmespath library
1. Download the latest jmespath.php library package from https://github.com/jmespath/jmespath.php/releases
2. Remove the lib/jmespath/src folder
3. Copy the src directory to lib/jmespath/ folder
4. Copy the associated following files to the jmespath directory:
     - CHANGELOG.md
     - composer.json
     - LICENSE
     - README.md
