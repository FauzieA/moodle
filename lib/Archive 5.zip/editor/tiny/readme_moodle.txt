For instructions on how to import TinyMCE into Moodle, see readme_moodle.md.
