Instructions to import/update Symfony Deprecation contracts library into Moodle:

1. Download the latest Symfony Deprecation contracts library from https://github.com/symfony/deprecation-contracts
2. Copy all the files to symfony/deprecation-contracts folder
