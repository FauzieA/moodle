See instructions in lib/php-di/readme_moodle.md
