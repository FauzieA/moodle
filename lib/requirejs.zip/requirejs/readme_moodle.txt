Description of import into Moodle:
1. Download from https://requirejs.org/docs/download.html
2. Put the require.js and require.min.js and LICENSE file in this folder.
3. Update lib/thirdpartylibs.xml with the latest version information.
4. Check that core_privacy\local\request\moodle_content_writer::write_html_data() does not need to be updated.
