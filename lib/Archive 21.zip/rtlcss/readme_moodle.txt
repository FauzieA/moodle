RTLCSS
------

Downloaded from: https://github.com/moodlehq/rtlcss-php

Import procedure:

- Copy all the files from the folder 'src/MoodleHQ/RTLCSS/' in this directory.
- Copy the license file.
