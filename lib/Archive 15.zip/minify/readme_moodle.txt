Description of MatthiasMullie\Minify import into Moodle

1) Go to https://github.com/matthiasmullie/minify/releases

Download the latest minify "Source code (zip)" and unzip it:

mv minify-X.Y.ZZ/src /path/to/moodle/lib/minify/matthiasmullie-minify/
mv minify-X.Y.ZZ/data /path/to/moodle/lib/minify/matthiasmullie-minify/

2) Go to https://github.com/matthiasmullie/path-converter/releases/ and unzip

Download the latest path-converter Source code (zip) and unzip it:

mv path-converter-A.B.C/src/ /path/to/moodle/lib/minify/matthiasmullie-pathconverter/

3) Apply the following patches:

N/A
