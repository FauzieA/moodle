Instructions to import/update the Slim Framework Moodle:

1. Update any dependencies, including Guzzle
2. Download the latest release from https://github.com/slimphp/Slim
3. Replace the files in slim/* with those in the zip
