<?php
$string['pluginname'] = 'This would be valid filename for module, not a block';
