<?php
$plugin->version = 2014122455;
$plugin->component = 'block_bah';
