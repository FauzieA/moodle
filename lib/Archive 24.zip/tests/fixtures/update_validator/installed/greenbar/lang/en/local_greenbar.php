<?php
$string['pluginname'] = 'Foo bar!';
