<?php
// Support for the $module has been dropped in Moodle 3.0.
$module->version = 2013031900;
