<?php
$plugin->version = 2014122455;
$plugin->component = 'mod_bah';
