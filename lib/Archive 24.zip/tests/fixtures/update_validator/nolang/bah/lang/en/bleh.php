<?php
$string['pluginnname'] = 'Root directory mismatch';
