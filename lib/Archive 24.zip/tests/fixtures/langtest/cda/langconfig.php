<?php

$string['thislanguage'] = 'Circular dependency A';
$string['parentlanguage'] = 'cdc';
