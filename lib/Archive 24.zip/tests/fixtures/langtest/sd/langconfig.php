<?php

$string['thislanguage'] = 'Self dependency';
$string['parentlanguage'] = 'sd';
