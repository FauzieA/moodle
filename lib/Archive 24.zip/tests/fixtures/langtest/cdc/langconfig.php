<?php

$string['thislanguage'] = 'Circular dependency C';
$string['parentlanguage'] = 'cdb';
