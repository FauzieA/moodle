<?php

namespace Packback\Lti1p3;

use Exception;

class LtiException extends Exception
{
}
