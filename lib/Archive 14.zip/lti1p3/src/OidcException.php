<?php

namespace Packback\Lti1p3;

use Exception;

class OidcException extends Exception
{
}
