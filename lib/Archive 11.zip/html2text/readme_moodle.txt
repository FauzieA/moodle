Description of Html2Text library import into Moodle

Instructions
------------
1. Download the latest release of Html2Text from https://github.com/mtibben/html2text/releases/
2. Extract the contents of the release archive into a directory.
3. Copy src to lib/html2text/src
4. Update README
5. Update composer.json

Imported from: https://github.com/mtibben/html2text/releases/
