See instructions in lib/guzzlehttp/readme_moodle.md
