OpenSpout
---------

Downloaded from: https://github.com/openspout/openspout

Import procedure:

* Copy all the files from the folder 'src' directory.
* Copy the LICENSE, README.md and composer.json files from the root of the project.
* Update lib/thirdpartylibs.xml with the latest version.
