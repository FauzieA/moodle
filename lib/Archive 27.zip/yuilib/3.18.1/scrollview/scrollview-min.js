YUI.add("scrollview",function(e,t){e.Base.plug(e.ScrollView,e.Plugin.ScrollViewScrollbars)},"3.18.1",{requires:["scrollview-base","scrollview-scrollbars"]});
