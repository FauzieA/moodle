YUI.add("file",function(e,t){var n=e.config.win;n&&n.File&&n.FormData&&n.XMLHttpRequest?e.File=e.FileHTML5:e.File=e.FileFlash},"3.18.1",{requires:["file-flash","file-html5"]});
