YUI.add("range-slider",function(e,t){e.Slider=e.Base.build("slider",e.SliderBase,[e.SliderValueRange,e.ClickableRail])},"3.18.1",{requires:["slider-base","slider-value-range","clickable-rail"]});
