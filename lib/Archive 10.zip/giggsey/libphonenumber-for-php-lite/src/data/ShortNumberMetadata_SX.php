<?php

/**
 * libphonenumber-for-php-lite data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

return [
    'id' => 'SX',
    'countryCode' => 0,
    'generalDesc' => [
        'pattern' => '9\\d\\d',
        'posLength' => [
            3,
        ],
    ],
    'tollFree' => [
        'pattern' => '9(?:19|88)',
        'example' => '919',
    ],
    'premiumRate' => [
        'posLength' => [
            -1,
        ],
    ],
    'emergency' => [
        'pattern' => '919',
        'example' => '919',
    ],
    'shortCode' => [
        'pattern' => '9(?:19|88)',
        'example' => '919',
    ],
    'standardRate' => [
        'posLength' => [
            -1,
        ],
    ],
    'carrierSpecific' => [
        'posLength' => [
            -1,
        ],
    ],
    'smsServices' => [
        'posLength' => [
            -1,
        ],
    ],
    'internationalPrefix' => '',
    'numberFormat' => [],
];
