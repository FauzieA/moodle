<?php

/**
 * libphonenumber-for-php-lite data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

return [
    'id' => 'SZ',
    'countryCode' => 0,
    'generalDesc' => [
        'pattern' => '9\\d\\d',
        'posLength' => [
            3,
        ],
    ],
    'tollFree' => [
        'pattern' => '999',
        'example' => '999',
    ],
    'premiumRate' => [
        'posLength' => [
            -1,
        ],
    ],
    'emergency' => [
        'pattern' => '999',
        'example' => '999',
    ],
    'shortCode' => [
        'pattern' => '999',
        'example' => '999',
    ],
    'standardRate' => [
        'posLength' => [
            -1,
        ],
    ],
    'carrierSpecific' => [
        'posLength' => [
            -1,
        ],
    ],
    'smsServices' => [
        'posLength' => [
            -1,
        ],
    ],
    'internationalPrefix' => '',
    'numberFormat' => [],
];
