WebAuthn
--------------

https://github.com/lbuchs/WebAuthn

Instructions to import WebAuthn into Moodle:

1. Download the latest release from https://github.com/lbuchs/WebAuthn/releases
   (choose "Source code")
2. Copy everything from the zip but "_test" directory and put them in lib/webauthn directory
3. Update this readme_moodle file if needed
