# Spatie's Cloneable trait

## Installation

1. Visit https://github.com/spatie/php-cloneable/
2. Download the latest release
3. Unzip in this folder
4. Update `thirdpartylibs.xml`
5. Remove any unnecessary files, including:
 - Any tests
 - CHANGELOG.md
 - composer.json
 - psalm.xml.dist
 - undo_configure.sh
