# core_webservice (subsystem / plugintype) Upgrade notes

## 4.5rc1

### Deprecated

- The `token_table` and `token_filter` classes have been deprecated, in favour of new report builder implementation.

  For more information see [MDL-79496](https://tracker.moodle.org/browse/MDL-79496)
