# core_availability (subsystem) Upgrade notes

## 4.5

### Removed

- The previously deprecated renderer `render_core_availability_multiple_messages` method has been removed.

  For more information see [MDL-82223](https://tracker.moodle.org/browse/MDL-82223)
