# core_portfolio (subsystem / plugintype) Upgrade notes

## 5.0

### Removed

- Removed portfolio_mahara plugin from core

  For more information see [MDL-84308](https://tracker.moodle.org/browse/MDL-84308)
