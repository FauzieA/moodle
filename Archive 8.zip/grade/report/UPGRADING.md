# gradereport (plugin type) Upgrade notes

## 5.0

### Removed

- The previously deprecated `grade_report::get_lang_string` method has been removed

  For more information see [MDL-78780](https://tracker.moodle.org/browse/MDL-78780)
