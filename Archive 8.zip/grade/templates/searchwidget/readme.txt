NOTE: Templates inside this directory have been deprecated since Moodle 4.3 and will be removed in 4.7.

They are only retained so that plugins using the now-deprecated searchwidget located in:

'grade/amd/src/searchwidget/basewidget.js'

can continue to use this widget in a working state during the deprecation period.
