# report_insights Upgrade notes

## 5.0

### Removed

- report_insights_set_notuseful_prediction() external function has been fully removed.

  For more information see [MDL-84036](https://tracker.moodle.org/browse/MDL-84036)
- report_insights_set_fixed_prediction() external function has been fully removed.

  For more information see [MDL-84036](https://tracker.moodle.org/browse/MDL-84036)
