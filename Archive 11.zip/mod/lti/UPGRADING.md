# mod_lti Upgrade notes

## 5.0

### Removed

- Final removal of deprecated `lti_libxml_disable_entity_loader` function

  For more information see [MDL-78635](https://tracker.moodle.org/browse/MDL-78635)
