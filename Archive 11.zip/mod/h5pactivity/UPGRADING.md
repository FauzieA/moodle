# mod_h5pactivity Upgrade notes

## 5.0

### Changed

- The external function get_user_attempts now returns the total number of attempts.

  For more information see [MDL-82775](https://tracker.moodle.org/browse/MDL-82775)
