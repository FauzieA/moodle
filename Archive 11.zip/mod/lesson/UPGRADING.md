# mod_lesson Upgrade notes

## 5.0

### Removed

- Remove unused /mod/lesson/tabs.php

  For more information see [MDL-82937](https://tracker.moodle.org/browse/MDL-82937)
