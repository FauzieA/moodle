# mod (plugin type) Upgrade notes

## 5.0

### Removed

- Remove mod_survey for Moodle 5.0

  For more information see [MDL-82457](https://tracker.moodle.org/browse/MDL-82457)
- Remove mod_chat from Moodle 5.0

  For more information see [MDL-82457](https://tracker.moodle.org/browse/MDL-82457)

## 4.5

### Added

- Added new `FEATURE_QUICKCREATE` for modules that can be quickly created in the course wihout filling a previous form.

  For more information see [MDL-81767](https://tracker.moodle.org/browse/MDL-81767)
