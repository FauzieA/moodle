# mod_book Upgrade notes

## 5.0

### Deprecated

- The method book_get_nav_classes has been finally
  deprecated and will now throw an exception if called.

  For more information see [MDL-81328](https://tracker.moodle.org/browse/MDL-81328)
