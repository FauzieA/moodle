# mod_folder Upgrade notes

## 5.0

### Removed

- Method htmllize_tree() has been removed. Please use renderable_tree_elements instead

  For more information see [MDL-79214](https://tracker.moodle.org/browse/MDL-79214)
