FPDI
==================================

No changes from the upstream version have been made. Both FPDI and FPDF_TPL have
been downloaded and unzipped to this directory.

Information
-----------

URL: http://www.setasign.de/products/pdf-php-solutions/fpdi/
Download from: http://www.setasign.de/products/pdf-php-solutions/fpdi/downloads
Documentation: http://www.setasign.de/products/pdf-php-solutions/fpdi/manuals/
License: The MIT License (MIT)

Installation
------------
1) Download the latest version of fpdi from the url above.
2) Unzip the src directory files into this directory.
3) Update mod/assign/feedback/editpdf/fpdi/src/Tcpdf/Fpdi.php(or whichever file it has been replaced with) to extend 'pdf' instead of 'TCPDF'.
