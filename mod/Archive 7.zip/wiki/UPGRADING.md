# mod_wiki Upgrade notes

## 5.0

### Removed

- Final deprecation of mod_wiki_renderer\wiki_info()

  For more information see [MDL-78926](https://tracker.moodle.org/browse/MDL-78926)
