import {createLayout as createFullScreenWindow} from './layout/fullscreen';

export {
    createFullScreenWindow
};
