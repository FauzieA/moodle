# tool_mobile Upgrade notes

## 5.0

### Removed

- Remove chat and survey support from tool_mobile.

  For more information see [MDL-82457](https://tracker.moodle.org/browse/MDL-82457)
