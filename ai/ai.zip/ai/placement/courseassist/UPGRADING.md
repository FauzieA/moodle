# aiplacement_courseassist Upgrade notes

## 5.0

### Added

- The `aiplacement_courseassist` templates and CSS have been modified. These changes allow for multiple actions to be nested in a dropdown menu.

  For more information see [MDL-82942](https://tracker.moodle.org/browse/MDL-82942)
