# block_social_activities Upgrade notes

## 5.0

### Removed

- 'Activity' selector in social_activities block has been deleted.

  For more information see [MDL-83733](https://tracker.moodle.org/browse/MDL-83733)
