# core_block (subsystem / plugintype) Upgrade notes

## 5.0

### Removed

- Removed block_mnet_hosts plugin from core

  For more information see [MDL-84309](https://tracker.moodle.org/browse/MDL-84309)
