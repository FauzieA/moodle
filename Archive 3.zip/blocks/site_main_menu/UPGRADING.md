# block_site_main_menu Upgrade notes

## 5.0

### Removed

- 'Activity' selector in site_main_menu block has been deleted.

  For more information see [MDL-83733](https://tracker.moodle.org/browse/MDL-83733)
